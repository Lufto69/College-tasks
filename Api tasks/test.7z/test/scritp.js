const wraper = document.querySelector('.test'),
    submit = document.querySelector('.submit');
let amount = 0,
    amountTrue = 0;

const value = [
    {
        question: 'Кто такой Вадим?',
        value: [
            'Шарик',
            'Лох',
            'Пельмень'
        ],
        answer: 'Лох'
    },
    {
        question: 'Серёга гоняет на?',
        value: [
            'Двенашке',
            'Пятёрке',
            'Четырке'
        ],
        answer: 'Четырке'
    }
    
]

value.forEach((elem, i) => {
    let itemTest = document.createElement('div')
    itemTest.classList.add('test__item')
    itemTest.innerHTML = `
        <div class="test__question">${i+1}. ${elem.question}</div>
        <div class="test__answer">
            <label><input type="radio" name="${i}" value="${elem.value[0]}">${elem.value[0]}</input></label>
            <label><input type="radio" name="${i}" value="${elem.value[1]}">${elem.value[1]}</input></label>
            <label><input type="radio" name="${i}" value="${elem.value[2]}">${elem.value[2]}</input></label>
        </div>
    `
    wraper.append(itemTest)
    amount++
})

submit.addEventListener('click', () => {
    const itemTests = document.querySelectorAll('.test__item')
    
    itemTests.forEach((i, e) => {
        const answers = i.querySelectorAll('input')

        answers.forEach(answer => {
            if (answer.checked && answer.value == value[e].answer) {
                i.classList.add('active_true')
                amountTrue++
            } else if (answer.checked && answer.value != value[e].answer) {
                i.classList.add('active_false')

                const trueAnswer = document.createElement('div')
                trueAnswer.innerHTML = `Правильный ответ: <span class='true_answer'>${value[e].answer}</span>`
                i.append(trueAnswer)
            }
            answer.setAttribute('disabled', '');
        })
    })
        
    submit.remove()

    const amountQuestion = document.createElement('div')
    amountQuestion.classList.add('amount_question')
    amountQuestion.innerHTML = `<span>${amountTrue}</span> / ${amount}`
    wraper.append(amountQuestion)

})